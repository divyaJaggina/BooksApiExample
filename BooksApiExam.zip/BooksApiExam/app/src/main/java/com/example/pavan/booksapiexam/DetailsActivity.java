package com.example.pavan.booksapiexam;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class DetailsActivity extends AppCompatActivity {
ImageView dimage;
TextView dtitle,dauthor,dpublisher,dpublishdate,ddesc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        dimage=findViewById(R.id.dimage);
        dtitle=findViewById(R.id.dtitle);
        dauthor=findViewById(R.id.dauthor);
        dpublisher=findViewById(R.id.dpublisher);
        dpublishdate=findViewById(R.id.dpublishdate);
        ddesc=findViewById(R.id.ddesc);
        Intent i=getIntent();
        String image=i.getStringExtra("image");
        String title=i.getStringExtra("title");
        String author=i.getStringExtra("author");
     //   String desc=i.getStringExtra("desc");
        String publisher=i.getStringExtra("publisher");
        String publishdate=i.getStringExtra("publishdate");


        Picasso.with(this).load(image).into(dimage);
        dtitle.setText(title);
        dauthor.setText(author);
        dpublishdate.setText(publishdate);
        dpublisher.setText(publisher);
      //  ddesc.setText(desc);



    }
}

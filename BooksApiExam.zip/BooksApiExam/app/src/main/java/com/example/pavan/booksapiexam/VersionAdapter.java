package com.example.pavan.booksapiexam;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class VersionAdapter extends RecyclerView.Adapter<VersionAdapter.VersionHolder> {
   MainActivity mainActivity;
   ArrayList<Pojo> arrayList=new ArrayList<>();

    public VersionAdapter(MainActivity mainActivity, ArrayList<Pojo> arrayList) {
        this.arrayList=arrayList;
        this.mainActivity=mainActivity;
    }

    @NonNull
    @Override
    public VersionAdapter.VersionHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view=LayoutInflater.from(mainActivity).inflate(R.layout.row,viewGroup,false);



        return new VersionHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VersionAdapter.VersionHolder versionHolder,final int i) {
        Picasso.with(mainActivity).load(arrayList.get(i).getImage()).into(versionHolder.coverimage);
        versionHolder.titleid.setText(arrayList.get(i).getTitle());

        versionHolder.authorid.setText(arrayList.get(i).getAuthor());
        versionHolder.coverimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in=new Intent(mainActivity,DetailsActivity.class);
                in.putExtra("image",arrayList.get(i).getImage());
                in.putExtra("author",arrayList.get(i).getAuthor());
                in.putExtra("title",arrayList.get(i).getTitle());
                in.putExtra("publisher",arrayList.get(i).getPublisher());
                in.putExtra("publishdate",arrayList.get(i).getPublisheDate());
                //in.putExtra("desc",arrayList.get(i).getDescription());

                mainActivity.startActivity(in);


            }
        });

    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class VersionHolder extends RecyclerView.ViewHolder {
        ImageView coverimage;
        TextView authorid,titleid;
        public VersionHolder(@NonNull View itemView) {
            super(itemView);
            authorid=itemView.findViewById(R.id.authorid);
            titleid=itemView.findViewById(R.id.titleid);
            coverimage=itemView.findViewById(R.id.coverimage);
        }
    }
}

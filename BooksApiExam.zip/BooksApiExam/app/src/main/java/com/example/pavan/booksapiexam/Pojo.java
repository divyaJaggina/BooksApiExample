package com.example.pavan.booksapiexam;

public class Pojo {
String title;
    String author;

    public Pojo(MainActivity mainActivity, String title, String author, String publisher, String publisheDate, String image) {

        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.publisheDate = publisheDate;
        this.image = image;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getPublisheDate() {
        return publisheDate;
    }

    public void setPublisheDate(String publisheDate) {
        this.publisheDate = publisheDate;
    }




    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    String publisher;
    String publisheDate;
    String description;
    String image;


}

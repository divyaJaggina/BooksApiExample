package com.example.pavan.booksapiexam;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;

import android.os.Bundle;
import android.widget.ScrollView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<String> {
RecyclerView recyclerview;
  ArrayList<Pojo> arrayList;
  Pojo pojo;
  VersionAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerview=findViewById(R.id.recyclerview);
        getSupportLoaderManager().initLoader(1,null,this);
    }

    @NonNull
    @Override
    public Loader<String> onCreateLoader(final int i, @Nullable Bundle bundle) {
        return new AsyncTaskLoader<String>(this) {

            @Override
            protected void onStartLoading() {
                super.onStartLoading();
                onForceLoad();
            }

            @Nullable
            @Override
            public String loadInBackground() {
                String url="https://www.googleapis.com/books/v1/volumes?q=android";

                try {
                    URL url1=new URL(url);
                    HttpURLConnection httpURLConnection= (HttpURLConnection) url1.openConnection();

                    httpURLConnection.setRequestMethod("GET");

                    httpURLConnection.connect();

                    InputStream inputStream=httpURLConnection.getInputStream();
                    BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(inputStream));
                    StringBuilder result=new StringBuilder();
                    String line="";
                    while(line!=null){
                        line=bufferedReader.readLine();
                        result.append(line);
                    }
                    return result.toString();

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }


                return null;
            }
        };
    }

    @Override
    public void onLoadFinished(@NonNull Loader<String> loader, String s) {
arrayList=new ArrayList<>();

        try {
            JSONObject jsonObject=new JSONObject(s);

            JSONArray jsonArray=jsonObject.getJSONArray("items");

            for(int i=0;i<jsonArray.length();i++){

                JSONObject jsonObject1=jsonArray.getJSONObject(i);
                JSONObject jsonObject2=jsonObject1.getJSONObject("volumeInfo");

                String title=jsonObject2.getString("title");
                String author=jsonObject2.getString("authors");
                String publisher=jsonObject2.getString("publisher");
                String publishedDate=jsonObject2.getString("publishedDate");
          //      String description=jsonObject2.getString("description");

                JSONObject jsonObject3=jsonObject2.getJSONObject("imageLinks");
                String image = jsonObject3.getString("thumbnail");

pojo=new Pojo(this,title,author,publisher,publishedDate,image);
    arrayList.add(pojo);
            }
    adapter=new VersionAdapter(this,arrayList);
            recyclerview.setLayoutManager(new GridLayoutManager(this,2));
recyclerview.setAdapter(adapter);
        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    @Override
    public void onLoaderReset(@NonNull Loader<String> loader) {

    }
}
